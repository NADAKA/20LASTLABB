/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;
import java.util.Scanner;
/**
 *
 * @author estudiante
 */
public class JavaApplication2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int a;
        int b;
        
        System.out.println("ingrese a");
        Scanner D1= new Scanner(System.in);
        a = D1.nextInt();
        
        System.out.println("ingrese b");
        Scanner D2= new Scanner(System.in);
        b = D2.nextInt();
        
        if(a>b){
            System.out.println("el mayor es " + a + " el menor es " +b);
        }else{
            System.out.println("el mayor es " + b + " el menor es " +a);
        };
        // TODO code application logic here
    }
    
}
