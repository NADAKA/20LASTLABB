/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;
import java.util.Scanner;
/**
 *
 * @author estudiante
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int m;
        int c;
        
        System.out.println("ingrese m");
        Scanner D1= new Scanner(System.in);
        m = D1.nextInt();
        
        System.out.println("ingrese c");
        Scanner D2= new Scanner(System.in);
        c = D2.nextInt();
        
        int r = m + (c/2);
        
        System.out.println("El resultado es "+ r);
        
        // TODO code application logic here
    }
    
}
